/* *******************************************************************
 * Copyright (c) 2005 Contributors.
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://eclipse.org/legal/epl-v10.html 
 *  
 * Contributors: 
 *   Adrian Colyer			Initial implementation
 * ******************************************************************/
package org.aspectj.internal.lang.reflect;

import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;

import org.aspectj.lang.reflect.AjType;
import org.aspectj.lang.reflect.AjTypeSystem;
import org.aspectj.lang.reflect.InterTypeMethodDeclaration;

/**
 * @author colyer
 *
 */
public class InterTypeMethodDeclarationImpl extends InterTypeDeclarationImpl
		implements InterTypeMethodDeclaration {

	private String name;
	private Method baseMethod;
	private int parameterAdjustmentFactor = 1; // no of fake params at start of baseMethod
	private AjType<?>[] parameterTypes;
	private Type[] genericParameterTypes;
	private AjType<?> returnType;
	private Type genericReturnType;
	private AjType<?>[] exceptionTypes;
	
	/**
	 * @param decType
	 * @param target
	 * @param mods
	 */
	public InterTypeMethodDeclarationImpl(AjType<?> decType, String target,
			int mods, String name, Method itdInterMethod) {
		super(decType, target, mods);
		this.name = name;
		this.baseMethod = itdInterMethod;
	}

	public InterTypeMethodDeclarationImpl(AjType<?> decType, AjType<?> targetType, Method base) {
		super(decType,targetType,base.getModifiers());
		this.parameterAdjustmentFactor = 0;
		this.name = base.getName();
		this.baseMethod = base;
	}
	
	/* (non-Javadoc)
	 * @see org.aspectj.lang.reflect.InterTypeMethodDeclaration#getName()
	 */
	public String getName() {
		return this.name;
	}

	/* (non-Javadoc)
	 * @see org.aspectj.lang.reflect.InterTypeMethodDeclaration#getReturnType()
	 */
	public AjType<?> getReturnType() {
		return AjTypeSystem.getAjType(baseMethod.getReturnType());
	}

	/* (non-Javadoc)
	 * @see org.aspectj.lang.reflect.InterTypeMethodDeclaration#getGenericReturnType()
	 */
	public Type getGenericReturnType() {
		Type gRet = baseMethod.getGenericReturnType();
		if (gRet instanceof Class) {
			return AjTypeSystem.getAjType((Class<?>)gRet);
		}
		return gRet;
	}

	/* (non-Javadoc)
	 * @see org.aspectj.lang.reflect.InterTypeMethodDeclaration#getParameters()
	 */
	public AjType<?>[] getParameterTypes() {
		Class<?>[] baseTypes = baseMethod.getParameterTypes();
		AjType<?>[] ret = new AjType<?>[baseTypes.length -parameterAdjustmentFactor];
		for (int i = parameterAdjustmentFactor; i < baseTypes.length; i++) {
			ret[i-parameterAdjustmentFactor] = AjTypeSystem.getAjType(baseTypes[i]);
		}
		return ret;
	}

	/* (non-Javadoc)
	 * @see org.aspectj.lang.reflect.InterTypeMethodDeclaration#getGenericParameters()
	 */
	public Type[] getGenericParameterTypes() {
		Type[] baseTypes = baseMethod.getGenericParameterTypes();
		Type[] ret = new AjType<?>[baseTypes.length-parameterAdjustmentFactor];
		for (int i = parameterAdjustmentFactor; i < baseTypes.length; i++) {
			if (baseTypes[i] instanceof Class) {
				ret[i-parameterAdjustmentFactor] = AjTypeSystem.getAjType((Class<?>)baseTypes[i]);
			} else {
				ret[i-parameterAdjustmentFactor] = baseTypes[i];
			}
		}
		return ret;
	}

	/* (non-Javadoc)
	 * @see org.aspectj.lang.reflect.InterTypeMethodDeclaration#getTypeParameters()
	 */
	public TypeVariable<Method>[] getTypeParameters() {
		return baseMethod.getTypeParameters();
	}

	public AjType<?>[] getExceptionTypes() {
		Class<?>[] baseTypes = baseMethod.getExceptionTypes();
		AjType<?>[] ret = new AjType<?>[baseTypes.length];
		for (int i = 0; i < baseTypes.length; i++) {
			ret[i] = AjTypeSystem.getAjType(baseTypes[i]);
		}
		return ret;
	}

}
