
public class HW {
	public static void main(String[] args) {
		callPrint("Hello");
		callPrint(" ");
		callPrint("World");
		callPrint("\n");
	}
	
	public static void callPrint(String s) {
		System.out.print(s);		
	}
}