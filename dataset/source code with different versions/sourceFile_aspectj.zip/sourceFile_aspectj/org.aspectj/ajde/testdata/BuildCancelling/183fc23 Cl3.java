public class Cl3 {
	public static void callPrint(String s) {
	}
}