
package pkg;

public interface InPackage { }