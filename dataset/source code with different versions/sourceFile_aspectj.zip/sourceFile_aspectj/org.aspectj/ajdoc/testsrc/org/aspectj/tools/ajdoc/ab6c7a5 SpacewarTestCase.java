/* *******************************************************************
 * Copyright (c) 2003 Contributors.
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Mik Kersten     initial implementation 
 * ******************************************************************/
 package org.aspectj.tools.ajdoc;

import java.io.File;

import junit.framework.TestCase;

/**
 * @author Mik Kersten
 */
public class SpacewarTestCase extends TestCase {
	
	protected void setUp() throws Exception {
		super.setUp();
		new File("testdata/spacewar/docdir").delete();
	}
    
	public void testSimpleExample() {
		File outdir = new File("testdata/spacewar/docdir");
		File sourcepath = new File("testdata/spacewar");
		
		String[] args = { 
                "-classpath",
                AjdocTests.ASPECTJRT_PATH.getPath(),
                "-d", 
				outdir.getAbsolutePath(),
				"-sourcepath",
				sourcepath.getAbsolutePath(),
				"spacewar",
				"coordination" };
		
		org.aspectj.tools.ajdoc.Main.main(args);
		assertTrue(true);
	}
	
	public void testPublicModeExample() {
		File outdir = new File("testdata/spacewar/docdir");
		File sourcepath = new File("testdata/spacewar");
		
		String[] args = { 
		        "-public",
                "-classpath",
                AjdocTests.ASPECTJRT_PATH.getPath(),
		        "-d", 
				outdir.getAbsolutePath(),
				"-sourcepath",
				sourcepath.getAbsolutePath(),
				"spacewar",
				"coordination" };
		
		org.aspectj.tools.ajdoc.Main.main(args);
		assertTrue(true);
	}
	
	protected void tearDown() throws Exception {
		super.tearDown();
	}
}
