package pack;

public class ClassWithInnerEnum {
	
	public static enum E {A};
	
	public void somemethod() {
	}
	
}
