package pack;

public enum MyEnum {
	
	A;
	
}
