
/**
 * Test class.  This is a comment.
 */  
public abstract class InDefaultPackage {
	
	/**
	 * Mumble field.
	 */
	public String mumble = "xxx";
	public int pubfield;
	private String privfield = "mumble";
}