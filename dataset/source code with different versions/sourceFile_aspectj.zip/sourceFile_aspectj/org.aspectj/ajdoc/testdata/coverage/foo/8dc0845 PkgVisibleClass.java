/**
 * @author Mik Kersten
 */
class PkgVisibleClass {

    static class NestedClass { } 
    
    static aspect NestedAspect { } 
  
    private static aspect PrivateNestedAspect { } 
     
}
